Minimaxing 3.1 by HTML5 UP
html5up.net | @n33co
Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)


The very first responsive site template I ever made on 5grid (now upgraded to skelJS).
It's clean, minimal, and so generic you can use it for pretty much anything.

Feedback, bug reports, and comments are not only welcome, but strongly encouraged :)

AJ
n33.co @n33co dribbble.com/n33


Credits:

	Images:
		fotogrph (fotogrph.com)
	
	Other:
		jQuery (jquery.com)
		html5shiv.js (@afarkas @jdalton @jon_neal @rem)
		skelJS (skeljs.org)